﻿using bibModelKolpacki.Model;
using bibModelKolpacki;
using ConsoleTables;
using System;
using bibModelKarbowski;

namespace bibadmKolpacki
{
    class Program
    {
        enum SHOWMETHOD
        {
            XDOC,
            XS
        }
        static void Main(string[] args)
        {
            BDLibrary db = new(
                Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + DefaultFileNames.pathFolder
                );

            db.TestData();

            while (true)
            {
                Console.Clear();
                ShowMenu();
                char selection = Console.ReadKey().KeyChar;
                Console.WriteLine("\n");

                switch (selection)
                {
                    case 'w':
                    case 'W':
                        Console.WriteLine("Wybrałeś opcję W");
                        ShowData(db, SHOWMETHOD.XS);
                        break;
                    case 'a':
                    case 'A':
                        Console.WriteLine("Wybrałeś opcję A");
                        break;
                    case 'x':
                    case 'X':
                        return;

                    default:
                        Console.WriteLine("Nieprawidłowa opcja");
                        break;
                }

                Console.Write("Oczekiwanie na wcisniecie klawisza...");
                Console.ReadKey();
            }

        }

        static void ShowMenu()
        {
            string[] options = new string[] {
                "W - wyświetl dane (wszystkie)",
                "A - ksiażki dla podanego autora",
                "",
                "X - koniec"
            };

            foreach (string option in options)
            {
                Console.WriteLine(option);
            }
            Console.Write("Wybierz opcje: ");
        }

        static void ShowData(BDLibrary db, SHOWMETHOD method = SHOWMETHOD.XDOC)
        {
            if (method == SHOWMETHOD.XDOC)
            {
                foreach (string model in db.ReportData())
                {
                    Console.WriteLine(model);
                    Console.WriteLine();
                }
            }
            else if (method == SHOWMETHOD.XS)
            {
                Console.WriteLine("Autorzy:");
                Autorzy autorzy = db.ReportData2<Autorzy>();
                if (autorzy != null && autorzy.Autor.Length > 0)
                {
                    var table = new ConsoleTable("ID", "Nazwisko", "Imie", "RokUrodzenia");
                    foreach (AutorzyAutor autor in autorzy.Autor)
                    {
                        table.AddRow(autor.id, autor.nazwisko, autor.imię, autor.rokUr);
                    }
                    table.Write(Format.Alternative);
                    Console.WriteLine();
                }

                Console.WriteLine("Wydawcy:");
                Wydawcy wydawcy = db.ReportData2<Wydawcy>();
                if (autorzy != null && autorzy.Autor.Length > 0)
                {
                    var table = new ConsoleTable("ID", "Nazwa", "Strona");
                    foreach (WydawcyWydawca wydawca in wydawcy.Wydawca)
                    {
                        table.AddRow(wydawca.id, wydawca.nazwa, wydawca.strona);
                    }
                    table.Write(Format.Alternative);
                    Console.WriteLine();
                }

                Console.WriteLine("Ksiazki:");
                Ksiazki ksiazki = db.ReportData2<Ksiazki>();
                if (autorzy != null && autorzy.Autor.Length > 0)
                {
                    var table = new ConsoleTable("ID", "Tytul", "ISBN", "Cena", "idAutora", "idWydawcy");
                    foreach (KsiazkiKsiazkaExt ksiazka in ksiazki.Ksiazka)
                    {
                        table.AddRow(ksiazka.id, ksiazka.tytul, ksiazka.ISBN, ksiazka.cena, ksiazka.idAutora, ksiazka.idWydawnictwa);
                    }
                    table.Write(Format.Alternative);
                    Console.WriteLine();
                }

                Console.WriteLine("Autorzy LINQ");
                var autorzyLQ = db.ReportDataLQAutorzy();
                if (autorzyLQ != null)
                {
                    var table = new ConsoleTable("ID", "Nazwisko", "Imie", "RokUrodzenia");
                    foreach (var item in autorzyLQ)
                    {
                        table.AddRow(item.id, item.nazwisko, item.imię, item.rokUr);
                    }
                    table.Write(Format.Alternative);
                    Console.WriteLine();
                }

                Console.WriteLine("Wydawcy LINQ");
                var wydawcyLQ = db.ReportDataLQWydawcy();
                if (wydawcyLQ != null)
                {
                    var table = new ConsoleTable("ID", "Nazwa", "Strona"); ;
                    foreach (var item in wydawcyLQ)
                    {
                        table.AddRow(item.id, item.nazwa, item.strona);
                    }
                    table.Write(Format.Alternative);
                    Console.WriteLine();
                }

                Console.WriteLine("Ksiazki LINQ");
                var ksiazkiLQ = db.ReportDataLQKsiązki();
                if (ksiazkiLQ != null)
                {
                    var table = new ConsoleTable("ID", "Tytul", "Autor", "Cena", "ISBN", "Wydawnictwo"); ;
                    foreach (var item in ksiazkiLQ)
                    {
                        table.AddRow(item.id, item.tytul, item.autorNazwisko + " " + item.autorImie, item.cena, item.ISBN, item.wydawnictwoNazwa);
                    }
                    table.Write(Format.Alternative);
                    Console.WriteLine();
                }

            }

        }
    }
}