﻿using bibKliKolpacki;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Storage;
using Windows.System;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

//Szablon elementu Pusta strona jest udokumentowany na stronie https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x415

namespace bibKliKolpacki
{
    /// <summary>
    /// Pusta strona, która może być używana samodzielnie lub do której można nawigować wewnątrz ramki.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
            if (ApplicationData.Current.LocalSettings.Values.ContainsKey("appTheme"))
            {
                string theme = ApplicationData.Current.LocalSettings.Values["appTheme"].ToString();
                if (Window.Current.Content is FrameworkElement rootElement)
                {
                    switch (theme)
                    {
                        case "Light":
                            rootElement.RequestedTheme = ElementTheme.Light;
                            break;
                        case "Dark":
                            rootElement.RequestedTheme = ElementTheme.Dark;
                            break;
                        case "System":
                            rootElement.RequestedTheme = ElementTheme.Default;
                            break;
                        default:
                            rootElement.RequestedTheme = ElementTheme.Default;
                            break;
                    }
                }
            }
            (App.Current as App).dbUWP.TestData();
        }

        private async void btStronaWWW_Tapped(object sender, TappedRoutedEventArgs e)
        {
            await Launcher.LaunchUriAsync(new Uri("https://ukw.edu.pl"));
        }

        private void btUstawienia_Tapped(object sender, TappedRoutedEventArgs e)
        {
            Frame.Navigate(typeof(SettingPage));
        }

        private void btHelp_Tapped(object sender, TappedRoutedEventArgs e)
        {
            if (frmMain.CurrentSourcePageType != typeof(HelpPage))
            {
                frmMain.Navigate(typeof(HelpPage));
            }
        }

        private void NavView_BackRequested(NavigationView sender, NavigationViewBackRequestedEventArgs args)
        {
            frmMain.GoBack();
        }

        private void NavView_ItemInvoked(NavigationView sender, NavigationViewItemInvokedEventArgs args)
        {
            var name = args.InvokedItemContainer.Name;
            switch (name)
            {
                case "SettingsNavPaneItem":
                    if (frmMain.CurrentSourcePageType != typeof(SettingPage))
                    {
                        frmMain.Navigate(typeof(SettingPage));
                    }
                    break;
                case "AuthorsListMenuItem":
                    if (frmMain.CurrentSourcePageType != typeof(AuthorsPage))
                    {
                        frmMain.Navigate(typeof(AuthorsPage));
                    }
                    break;
                case "PublishersListMenuItem":
                    break;
                case "BooksListMenuItem":
                    break;
                default:
                    break;
            }
        }
    }
}
