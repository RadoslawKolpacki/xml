﻿using bibKliKolpacki;
using bibModelKolpacki.Model;
using Microsoft.Toolkit.Uwp.UI.Controls;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

//Szablon elementu Pusta strona jest udokumentowany na stronie https://go.microsoft.com/fwlink/?LinkId=234238

namespace bibKliKolpacki
{
    /// <summary>
    /// Pusta strona, która może być używana samodzielnie lub do której można nawigować wewnątrz ramki.
    /// </summary>
    public sealed partial class AuthorsPage : Page
    {
        DataGridDataSourceAuthors AuthorsViewModel;
        public AuthorsPage()
        {
            AuthorsViewModel = new DataGridDataSourceAuthors();
            AuthorsViewModel.Autorzy = (App.Current as App).dbUWP.AuthorsList;
            /*{
                Autorzy = { 
                    new AutorzyAutor {id = 1,imię = "Jaś", nazwisko="Kowalski"},
                    new AutorzyAutor {id = 2,imię = "Adam", nazwisko="Adamski"},
                    new AutorzyAutor {id = 3,imię = "Piotr", nazwisko="Piotrkowski"},
                    new AutorzyAutor {id = 4,imię = "Tomasz", nazwisko="Tomaszewski"},
                }
            
            };
            */
            this.InitializeComponent();
        }
        protected override void OnNavigatingFrom(NavigatingCancelEventArgs e)
        {
            SaveAuthors();
            base.OnNavigatingFrom(e);
        }

        private void SaveAuthors()
        {
            IEnumerable<AutorzyAutor> authDG = dataGrid.ItemsSource.Cast<AutorzyAutor>();
            Autorzy authors = new Autorzy()
            {
                Autor = authDG.ToArray()
            };
            //metoda zapisu przez obiekt bazy danych
            (App.Current as App).dbUWP.AuthorsList = authDG.ToList();
            (App.Current as App).dbUWP.Serialize(authors);
        }
    }
    class DataGridDataSourceAuthors
    {
        public List<AutorzyAutor> Autorzy = new List<AutorzyAutor>();
    }
}
