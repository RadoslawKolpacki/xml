﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Storage;
using Windows.UI.Xaml.Controls;
using System.Xml.Serialization;
using System.IO;
using bibKliKolpacki;
using bibModelKolpacki.Model;

namespace bibKliKolpacki
{
    public class DBLibraryUWP
    {
        public StorageFolder pathUWP = KnownFolders.DocumentsLibrary;
        public string authorsFile, publishersFile, booksFile;
        public List<AutorzyAutor> AuthorsList;
        public DBLibraryUWP(string authorsFile = DefaultFileNames.authorsFile + ".xml", string publishersFile = DefaultFileNames.publishersFile + ".xml", string booksFile = DefaultFileNames.booksFile + ".xml")
        {
            this.authorsFile = authorsFile;
            this.publishersFile = publishersFile;
            this.booksFile = booksFile;
        }
        public async void TestData()
        {
            var itemAf = await pathUWP.TryGetItemAsync(authorsFile);
            var itemPf = await pathUWP.TryGetItemAsync(publishersFile);
            var itemBf = await pathUWP.TryGetItemAsync(booksFile);
            string errFiles = (itemAf == null ? authorsFile : (itemPf == null ? publishersFile : (itemBf == null ? booksFile : "")));
            if (errFiles != "")
            {
                var dlg = new ContentDialog()
                {
                    Title = "Błąd danych!!!",
                    Content = "Plik danych: " + pathUWP.Name + "\\" + errFiles + "\njest niedostępny.\nProszę urchomić moduł administracyjny",
                    CloseButtonText = "OK"
                };
                await dlg.ShowAsync();
                App.Current.Exit();
            }
            AuthorsList = Deserialize(itemAf as StorageFile).Autor.ToList();

        }
        Autorzy Deserialize(StorageFile storageFile)
        {
            var xmlSerializer = new XmlSerializer(typeof(Autorzy));
            try
            {
                using (Stream reader = storageFile.OpenStreamForReadAsync().Result)
                {
                    return (Autorzy)xmlSerializer.Deserialize(reader);
                }
            }
            catch (Exception ex)
            {
                return default;
            }
        }
        public async void Serialize(Autorzy dat)
        {
            var itemAf = await pathUWP.TryGetItemAsync(authorsFile);
            var file = itemAf as StorageFile;
            var serXml = new XmlSerializer(typeof(Autorzy));
            Stream stream = await file.OpenStreamForWriteAsync();
            using (stream)
            {
                serXml.Serialize(stream, dat);
            }
        }
    }
}
