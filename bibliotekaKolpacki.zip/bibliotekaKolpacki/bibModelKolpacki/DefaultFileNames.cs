﻿using System;
using System.Collections.Generic;
using System.Text;

namespace bibModelKolpacki.Model
{
    public static class DefaultFileNames
    {
        public const string authorsFile = "plikAutorzyKarbowski",
            publishersFile = "plikWydawnictwaKarbowski",
            booksFile = "plikKsiążkiKarbowski",
            pathFolder = "\\__ukw";
    }
}
