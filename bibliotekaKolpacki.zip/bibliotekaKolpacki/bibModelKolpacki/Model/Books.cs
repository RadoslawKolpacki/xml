﻿using System.Xml.Serialization;

namespace bibModelKolpacki.Model
{
}

namespace bibModelKolpacki.Model
{

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("xsd", "4.8.3928.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "", IsNullable = false)]
    public partial class Ksiazki
    {

        private KsiazkiKsiazkaExt[] ksiazkaField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("Ksiazka")]
        public KsiazkiKsiazkaExt[] Ksiazka
        {
            get
            {
                return this.ksiazkaField;
            }
            set
            {
                this.ksiazkaField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("xsd", "4.8.3928.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class KsiazkiKsiazkaExt
    {
        public string autorNazwisko;
        public string autorImie;
        private ulong idField;

        private string tytulField;

        private ulong idAutoraField;

        private string iSBNField;

        private float cenaField;

        private ulong idWydawnictwaField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public ulong id
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string tytul
        {
            get
            {
                return this.tytulField;
            }
            set
            {
                this.tytulField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public ulong idAutora
        {
            get
            {
                return this.idAutoraField;
            }
            set
            {
                this.idAutoraField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string ISBN
        {
            get
            {
                return this.iSBNField;
            }
            set
            {
                this.iSBNField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public float cena
        {
            get
            {
                return this.cenaField;
            }
            set
            {
                this.cenaField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public ulong idWydawnictwa
        {
            get
            {
                return this.idWydawnictwaField;
            }
            set
            {
                this.idWydawnictwaField = value;
            }
        }

        public string wydawnictwoNazwa { get; internal set; }
    }
}