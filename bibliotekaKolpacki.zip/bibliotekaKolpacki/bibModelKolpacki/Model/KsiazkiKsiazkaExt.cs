﻿

namespace bibModelKolpacki.Model
{
    public partial class KsiążkiKsiążkaExt : KsiazkiKsiazkaExt
    {
        public string autorImie { set; get; }
        public string autorNazwisko { set; get; }
        public string wydawnictwoNazwa { set; get; }
    }
}